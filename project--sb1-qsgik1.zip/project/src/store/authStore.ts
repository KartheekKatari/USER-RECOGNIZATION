import { create } from 'zustand';
import { User } from '../types';

interface AuthState {
  user: User | null;
  setUser: (user: User | null) => void;
  login: (username: string, password: string) => Promise<void>;
  signup: (username: string, password: string) => Promise<void>;
  logout: () => void;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  setUser: (user) => set({ user }),
  login: async (username: string, password: string) => {
    // TODO: Implement actual API call
    const mockUser: User = {
      id: '1',
      username,
      role: 'Employee',
    };
    set({ user: mockUser });
  },
  signup: async (username: string, password: string) => {
    // TODO: Implement actual API call
    const mockUser: User = {
      id: '1',
      username,
      role: 'Employee',
    };
    set({ user: mockUser });
  },
  logout: () => set({ user: null }),
}));