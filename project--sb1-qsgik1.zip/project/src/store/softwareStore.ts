import { create } from 'zustand';
import { Software } from '../types';

interface SoftwareState {
  software: Software[];
  addSoftware: (software: Software) => void;
  getSoftware: (id: string) => Software | undefined;
  getAllSoftware: () => Software[];
}

export const useSoftwareStore = create<SoftwareState>((set, get) => ({
  software: [],
  addSoftware: (software) =>
    set((state) => ({ software: [...state.software, software] })),
  getSoftware: (id) => get().software.find((s) => s.id === id),
  getAllSoftware: () => get().software,
}));