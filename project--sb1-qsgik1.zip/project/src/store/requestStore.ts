import { create } from 'zustand';
import { AccessRequest } from '../types';

interface RequestState {
  requests: AccessRequest[];
  addRequest: (request: AccessRequest) => void;
  updateRequestStatus: (id: string, status: 'Approved' | 'Rejected') => void;
  getPendingRequests: () => AccessRequest[];
  getUserRequests: (userId: string) => AccessRequest[];
}

export const useRequestStore = create<RequestState>((set, get) => ({
  requests: [],
  addRequest: (request) =>
    set((state) => ({ requests: [...state.requests, request] })),
  updateRequestStatus: (id, status) =>
    set((state) => ({
      requests: state.requests.map((request) =>
        request.id === id ? { ...request, status } : request
      ),
    })),
  getPendingRequests: () =>
    get().requests.filter((request) => request.status === 'Pending'),
  getUserRequests: (userId) =>
    get().requests.filter((request) => request.userId === userId),
}));