import React from 'react';
import { useAuthStore } from '../store/authStore';
import { useRequestStore } from '../store/requestStore';
import { useSoftwareStore } from '../store/softwareStore';
import { Plus, List } from 'lucide-react';

export default function Dashboard() {
  const user = useAuthStore((state) => state.user);
  const requests = useRequestStore((state) => state.requests);
  const software = useSoftwareStore((state) => state.software);

  if (!user) return null;

  return (
    <div className="space-y-6">
      <header>
        <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
        <p className="mt-2 text-sm text-gray-600">
          Welcome back, {user.username}
        </p>
      </header>

      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {/* Quick Actions */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <Plus className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Quick Actions
                  </dt>
                  <dd>
                    <div className="mt-4">
                      <a
                        href="#"
                        className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-indigo-600 hover:bg-indigo-700"
                      >
                        Request Access
                      </a>
                    </div>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Activity */}
        <div className="bg-white overflow-hidden shadow rounded-lg">
          <div className="p-5">
            <div className="flex items-center">
              <div className="flex-shrink-0">
                <List className="h-6 w-6 text-gray-400" />
              </div>
              <div className="ml-5 w-0 flex-1">
                <dl>
                  <dt className="text-sm font-medium text-gray-500 truncate">
                    Recent Activity
                  </dt>
                  <dd className="mt-4">
                    <ul className="divide-y divide-gray-200">
                      {requests.slice(0, 3).map((request) => (
                        <li key={request.id} className="py-2">
                          <p className="text-sm text-gray-600">
                            Access request for Software #{request.softwareId}:{' '}
                            <span
                              className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                                request.status === 'Approved'
                                  ? 'bg-green-100 text-green-800'
                                  : request.status === 'Rejected'
                                  ? 'bg-red-100 text-red-800'
                                  : 'bg-yellow-100 text-yellow-800'
                              }`}
                            >
                              {request.status}
                            </span>
                          </p>
                        </li>
                      ))}
                    </ul>
                  </dd>
                </dl>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}