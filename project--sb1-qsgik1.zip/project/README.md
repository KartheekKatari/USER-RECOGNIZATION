# User Access Management System

A web-based application for managing user access to various software applications within an organization.

## Features

- User Registration (Sign-Up)
- User Authentication (Login)
- Software Application Management
- Access Request Submission
- Access Request Approval/Rejection

## Project Structure

```
user-access-management/
├── src/
│   ├── components/
│   │   └── Layout.tsx
│   ├── pages/
│   │   ├── Login.tsx
│   │   └── Signup.tsx
│   ├── store/
│   │   └── authStore.ts
│   ├── types/
│   │   └── index.ts
│   ├── App.tsx
│   ├── main.tsx
│   └── index.css
├── public/
├── index.html
├── package.json
├── tsconfig.json
├── tsconfig.node.json
├── vite.config.ts
└── README.md
```

## Setup Instructions

1. Install dependencies:
   ```bash
   npm install
   ```

2. Start development server:
   ```bash
   npm run dev
   ```

3. Build for production:
   ```bash
   npm run build
   ```

## Technologies Used

- React
- TypeScript
- Tailwind CSS
- Zustand (State Management)
- React Router DOM
- Lucide React (Icons)
- Vite (Build Tool)